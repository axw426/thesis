#!/bin/bash

export PATH=/afs/cern.ch/sw/XML/texlive/latest/bin/x86_64-linux:$PATH
